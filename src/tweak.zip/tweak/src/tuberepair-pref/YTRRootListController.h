#import <Preferences/PSListController.h>

@interface YTRRootListController : PSListController

@end
