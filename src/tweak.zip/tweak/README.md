# TubeRepair

This is the TubeRepair Tweak, as hosted in bag.xml's repo. This redirects URLs from the classic YouTube app and the App Store YouTube App to any domain you specify in settings.
